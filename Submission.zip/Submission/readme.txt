I used cpp to write code.
For running admin i have created a Makefile so it can be easily compiled.
To compile just do this: make -f Makefile-part4
This will create admin.exe. You can simply run admin.exe and do not forget to pass it the argument (filename).